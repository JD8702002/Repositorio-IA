import java.awt.*;
import java.util.List;
import java.util.function.Function;
import javax.swing.*;

/**
 * Interfaz gráfica para el solucionador de 24-Puzzle.
 * Permite introducir un estado manual, generar uno aleatorio, seleccionar
 * la heurística y ver la solución y estadísticas.
 */
public class Puzzle24GUI extends JFrame {
    private JTextArea estadoArea;
    private JButton botonResolver;
    private JButton botonAleatorio;
    private JComboBox<String> heuristicaBox;
    private JTextField profundidadField;
    private JTextArea salidaArea;

    public Puzzle24GUI() {
        super("24-Puzzle Solver");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        initComponents();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));

        // entrada de estado y controles
        JPanel topPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        estadoArea = new JTextArea(5, 40);
        estadoArea.setBorder(BorderFactory.createTitledBorder("Estado inicial (25 números)"));
        topPanel.add(new JScrollPane(estadoArea));

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botonResolver = new JButton("Resolver");
        botonAleatorio = new JButton("Aleatorio");
        heuristicaBox = new JComboBox<>(new String[]{"manhattan", "lineal"});
        profundidadField = new JTextField("50", 4);
        controls.add(new JLabel("Heurística:"));
        controls.add(heuristicaBox);
        controls.add(new JLabel("Profundidad scramble:"));
        controls.add(profundidadField);
        controls.add(botonResolver);
        controls.add(botonAleatorio);
        topPanel.add(controls);

        panel.add(topPanel, BorderLayout.NORTH);

        // área de salida
        salidaArea = new JTextArea();
        salidaArea.setEditable(false);
        salidaArea.setBorder(BorderFactory.createTitledBorder("Salida"));
        panel.add(new JScrollPane(salidaArea), BorderLayout.CENTER);

        getContentPane().add(panel);

        // listeners
        botonResolver.addActionListener(e -> resolverEstado());
        botonAleatorio.addActionListener(e -> generarAleatorio());
    }

    private void resolverEstado() {
        String texto = estadoArea.getText().trim();
        if (texto.isEmpty()) {
            salidaArea.setText("Introduzca un estado o use 'Aleatorio'.\n");
            return;
        }
        try {
            Puzzle24 inicio = Main.parsearEstado(texto);
            if (!Puzzle24.esResoluble(inicio.obtenerFichas())) {
                salidaArea.setText("El estado no es resoluble.\n");
                return;
            }
            ejecutarSolver(inicio);
        } catch (Exception ex) {
            salidaArea.setText("Error al parsear el estado: " + ex.getMessage() + "\n");
        }
    }

    private void generarAleatorio() {
        int prof;
        try {
            prof = Integer.parseInt(profundidadField.getText());
        } catch (NumberFormatException ex) {
            prof = 50;
        }
        Puzzle24 alea = Puzzle24.estadoAleatorio(prof);
        estadoArea.setText(arrayToString(alea.obtenerFichas()));
        // resolver en segundo plano para no bloquear la interfaz
        new Thread(() -> ejecutarSolver(alea)).start();
    }

    private void ejecutarSolver(Puzzle24 inicio) {
        String heur = (String) heuristicaBox.getSelectedItem();
        Function<Puzzle24, Integer> fn = Main.HEURISTICAS.get(heur);
        salidaArea.setText("Estado inicial:\n" + inicio + "\n");
        // correr en hilo separado para no bloquear la EDT
        new Thread(() -> {
            IDAStarSolver solver = new IDAStarSolver(fn);
            List<String> sol = solver.resolver(inicio);
            SwingUtilities.invokeLater(() -> {
                if (sol == null) {
                    salidaArea.append("No se encontró solución\n");
                } else {
                    salidaArea.append("Longitud: " + sol.size() + "\n");
                    salidaArea.append("Movimientos: " + String.join("", sol) + "\n");
                    salidaArea.append(solver.estadisticas() + "\n");
                }
            });
        }).start();
    }

    private String arrayToString(int[] arr) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            sb.append(arr[i]);
            if (i < arr.length - 1) sb.append(' ');
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Puzzle24GUI gui = new Puzzle24GUI();
            gui.setVisible(true);
        });
    }
}
