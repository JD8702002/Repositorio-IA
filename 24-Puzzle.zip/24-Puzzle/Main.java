import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import javax.swing.*;


public class Main {
    public static final Map<String, Function<Puzzle24, Integer>> HEURISTICAS = new HashMap<>();

    static {
        HEURISTICAS.put("manhattan", Puzzle24::distanciaManhattan);
        HEURISTICAS.put("lineal", Puzzle24::conflictoLineal);
    }

    public static void main(String[] args) {
        // si no hay argumentos, abrimos una interfaz gráfica
        if (args.length == 0) {
            SwingUtilities.invokeLater(Main::crearYMostrarGUI);
            return;
        }
        boolean usarEstado = false;
        boolean generarAleatorio = false;
        String estadoCadena = null;
        int profundidad = 50;
        String heuristicaSeleccionada = "manhattan";
        boolean verbose = false;

        // parseo sencillo de argumentos
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-s":
                case "--state":
                    if (i + 1 < args.length) {
                        usarEstado = true;
                        estadoCadena = args[++i];
                    }
                    break;
                case "-r":
                case "--random":
                    generarAleatorio = true;
                    break;
                case "-d":
                case "--depth":
                    if (i + 1 < args.length) {
                        profundidad = Integer.parseInt(args[++i]);
                    }
                    break;
                case "-hue":
                case "--heuristic":
                    if (i + 1 < args.length) {
                        heuristicaSeleccionada = args[++i];
                    }
                    break;
                case "-v":
                case "--verbose":
                    verbose = true;
                    break;
                default:
                    // ignorar rest
            }
        }

        Puzzle24 inicio;
        if (usarEstado) {
            try {
                inicio = parsearEstado(estadoCadena);
                if (!Puzzle24.esResoluble(inicio.obtenerFichas())) {
                    System.err.println("El estado proporcionado no es resoluble");
                    return;
                }
            } catch (Exception ex) {
                System.err.println("Error al parsear el estado: " + ex.getMessage());
                return;
            }
        } else if (generarAleatorio) {
            inicio = Puzzle24.estadoAleatorio(profundidad);
        } else {
            System.err.println("Debe indicar -s <estado> o -r para generar uno aleatorio");
            return;
        }

        if (verbose) {
            System.out.println("Estado inicial:\n" + inicio);
        }

        if (heuristicaSeleccionada.equals("all")) {
            List<Resultados> resultados = new ArrayList<>();
            for (Map.Entry<String, Function<Puzzle24, Integer>> entry : HEURISTICAS.entrySet()) {
                System.out.println("\n== usando heurística " + entry.getKey() + " ==");
                IDAStarSolver solver = new IDAStarSolver(entry.getValue());
                List<String> sol = solver.resolver(inicio);
                if (sol == null) {
                    System.out.println("No se encontró solución");
                    resultados.add(new Resultados(entry.getKey(), -1, solver.getNodosExpandidos(), solver.getTiempoTranscurrido()));
                } else {
                    System.out.println("Longitud de la solución: " + sol.size());
                    System.out.println("Movimientos: " + String.join("", sol));
                    System.out.println(solver.estadisticas());
                    resultados.add(new Resultados(entry.getKey(), sol.size(), solver.getNodosExpandidos(), solver.getTiempoTranscurrido()));
                }
            }
            System.out.println("\nComparación:");
            System.out.printf("%-11s %5s %7s %8s%n", "heurística", "prof", "nodos", "tiempo(s)");
            for (Resultados r : resultados) {
                String prof = r.profundidad >= 0 ? String.valueOf(r.profundidad) : "-";
                System.out.printf("%-11s %5s %7d %8.4f%n", r.nombre, prof, r.nodos, r.tiempo);
            }
            return;
        }

        Function<Puzzle24, Integer> fn = HEURISTICAS.get(heuristicaSeleccionada);
        if (fn == null) {
            System.err.println("Heurística desconocida: " + heuristicaSeleccionada);
            return;
        }

        IDAStarSolver solver = new IDAStarSolver(fn);
        List<String> solucion = solver.resolver(inicio);
        if (solucion == null) {
            System.out.println("No se encontró solución");
        } else {
            System.out.println("Longitud de la solución: " + solucion.size());
            System.out.println("Movimientos: " + String.join("", solucion));
            System.out.println(solver.estadisticas());
        }
    }

    public static Puzzle24 parsearEstado(String s) {
        // permite separar con múltiples espacios, newlines etc
        String normalizada = s.trim().replaceAll("\\s+", " ");
        String[] partes = normalizada.split(" ");
        if (partes.length != Puzzle24.NUM_FICHAS) {
            throw new IllegalArgumentException("Se esperan " + Puzzle24.NUM_FICHAS + " números separados por espacios");
        }
        int[] vals = new int[Puzzle24.NUM_FICHAS];
        for (int i = 0; i < partes.length; i++) {
            vals[i] = Integer.parseInt(partes[i]);
        }
        return new Puzzle24(vals);
    }


    private static class Resultados {
        String nombre;
        int profundidad;
        long nodos;
        double tiempo;
        Resultados(String n, int p, long nod, double t) {
            nombre = n; profundidad = p; nodos = nod; tiempo = t;
        }
    }

    // ----------------------
    // interfaz gráfica
    // ----------------------
    private static void crearYMostrarGUI() {
        JFrame frame = new JFrame("24-Puzzle Solucionador");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // área de entrada
        JTextArea entrada = new JTextArea(5, 40);
        entrada.setLineWrap(true);
        entrada.setWrapStyleWord(true);
        JScrollPane spEntrada = new JScrollPane(entrada);

        JButton btnAleatorio = new JButton("Generar aleatorio");
        JSpinner spinnerProf = new JSpinner(new SpinnerNumberModel(50, 1, 1000, 1));
        JComboBox<String> cbHeuristica = new JComboBox<>(new String[]{"manhattan", "lineal", "all"});
        JButton btnResolver = new JButton("Resolver");

        JTextArea salida = new JTextArea(15, 40);
        salida.setEditable(false);
        JScrollPane spSalida = new JScrollPane(salida);

        JPanel topControls = new JPanel();
        topControls.add(new JLabel("Profundidad scramble:"));
        topControls.add(spinnerProf);
        topControls.add(btnAleatorio);
        topControls.add(new JLabel("Heurística:"));
        topControls.add(cbHeuristica);
        topControls.add(btnResolver);

        panel.add(topControls, BorderLayout.NORTH);
        panel.add(spEntrada, BorderLayout.CENTER);
        panel.add(spSalida, BorderLayout.SOUTH);

        // acciones
        btnAleatorio.addActionListener(e -> {
            int d = (Integer) spinnerProf.getValue();
            Puzzle24 est = Puzzle24.estadoAleatorio(d);
            entrada.setText(estadoAString(est));
        });

        btnResolver.addActionListener(e -> {
            String texto = entrada.getText().trim();
            if (texto.isEmpty()) {
                salida.append("Introduzca un estado o genere uno aleatorio\n");
                return;
            }
            Puzzle24 start;
            try {
                start = parsearEstado(texto);
            } catch (Exception ex) {
                salida.append("Error al parsear: " + ex.getMessage() + "\n");
                return;
            }
            if (!Puzzle24.esResoluble(start.obtenerFichas())) {
                salida.append("El estado no es resoluble\n");
                return;
            }
            String heur = (String) cbHeuristica.getSelectedItem();
            if (heur == null) heur = "manhattan";
            final Puzzle24 inicio = start;
            final String hfinal = heur;
            new Thread(() -> {
                IDAStarSolver solver = new IDAStarSolver(HEURISTICAS.get(hfinal));
                List<String> sol = solver.resolver(inicio);
                SwingUtilities.invokeLater(() -> {
                    if (sol == null) {
                        salida.append("No se encontró solución\n");
                    } else {
                        salida.append("Longitud solución: " + sol.size() + "\n");
                        salida.append("Movimientos: " + String.join("", sol) + "\n");
                        salida.append(solver.estadisticas() + "\n");
                    }
                });
            }).start();
        });

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }

    private static String estadoAString(Puzzle24 estado) {
        int[] vals = estado.obtenerFichas();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vals.length; i++) {
            sb.append(vals[i]);
            if (i < vals.length - 1) sb.append(' ');
        }
        return sb.toString();
    }
}
