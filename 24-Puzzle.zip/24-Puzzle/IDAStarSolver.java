import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * Implementación del algoritmo IDA* para el 24-puzzle.
 * Variables y métodos en español.
 */
public class IDAStarSolver {
    private final Function<Puzzle24, Integer> heuristica;
    private long nodosExpandidos;
    private double tiempoInicio;
    private List<String> caminoSolucion;
    private double tiempoTranscurrido;

    public IDAStarSolver(Function<Puzzle24, Integer> heuristica) {
        this.heuristica = heuristica;
    }

    public List<String> resolver(Puzzle24 estadoInicial) {
        nodosExpandidos = 0;
        tiempoInicio = System.nanoTime();
        int limite = heuristica.apply(estadoInicial);
        List<ParEstadoMov> camino = new ArrayList<>();
        camino.add(new ParEstadoMov(estadoInicial, ""));

        while (true) {
            ResultadoBusqueda r = buscar(camino, 0, limite);
            if (r.encontrado) {
                tiempoTranscurrido = (System.nanoTime() - tiempoInicio) / 1e9;
                caminoSolucion = r.camino;
                return r.camino;
            }
            if (r.minCota == Integer.MAX_VALUE) {
                tiempoTranscurrido = (System.nanoTime() - tiempoInicio) / 1e9;
                return null;
            }
            limite = r.minCota;
        }
    }

    private ResultadoBusqueda buscar(List<ParEstadoMov> camino, int g, int limite) {
        Puzzle24 nodo = camino.get(camino.size() - 1).estado;
        int f = g + heuristica.apply(nodo);
        if (f > limite) {
            return new ResultadoBusqueda(false, f, null);
        }
        if (nodo.esObjetivo()) {
            // extraer movimientos
            List<String> sol = new ArrayList<>();
            for (int i = 1; i < camino.size(); i++) {
                sol.add(camino.get(i).movimiento);
            }
            return new ResultadoBusqueda(true, f, sol);
        }
        nodosExpandidos++;
        int minCota = Integer.MAX_VALUE;
        for (Puzzle24.Movimiento mv : nodo.vecinos()) {
            Puzzle24 sucesor = mv.estado;
            String dir = mv.direccion;
            boolean ciclo = false;
            for (ParEstadoMov prev : camino) {
                if (ArraysEquals(sucesor, prev.estado)) {
                    ciclo = true;
                    break;
                }
            }
            if (ciclo) continue;
            camino.add(new ParEstadoMov(sucesor, dir));
            ResultadoBusqueda r = buscar(camino, g + 1, limite);
            if (r.encontrado)
                return r;
            if (r.minCota < minCota) {
                minCota = r.minCota;
            }
            camino.remove(camino.size() - 1);
        }
        return new ResultadoBusqueda(false, minCota, null);
    }

    private boolean ArraysEquals(Puzzle24 a, Puzzle24 b) {
        // comparar contenidos por toString o internamente
        return a.toString().equals(b.toString());
    }

    public String estadisticas() {
        return String.format("nodos=%d, tiempo=%.4fs, profundidad=%d",
                nodosExpandidos, tiempoTranscurrido,
                caminoSolucion == null ? 0 : caminoSolucion.size());
    }

    public long getNodosExpandidos() {
        return nodosExpandidos;
    }

    public double getTiempoTranscurrido() {
        return tiempoTranscurrido;
    }

    // clases auxiliares
    private static class ParEstadoMov {
        public final Puzzle24 estado;
        public final String movimiento;

        public ParEstadoMov(Puzzle24 e, String m) {
            this.estado = e;
            this.movimiento = m;
        }
    }

    private static class ResultadoBusqueda {
        public final boolean encontrado;
        public final int minCota;
        public final List<String> camino;

        public ResultadoBusqueda(boolean encontrado, int minCota, List<String> camino) {
            this.encontrado = encontrado;
            this.minCota = minCota;
            this.camino = camino;
        }
    }
}
