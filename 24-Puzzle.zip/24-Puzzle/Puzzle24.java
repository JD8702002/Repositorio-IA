import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Representa un estado del "24-puzzle" (tablero 5x5) y contiene
 * métodos utilitarios y heurísticas.
 * Las variables y métodos están en español para cumplir los requisitos.
 */
public class Puzzle24 {
    private final int[] fichas;     // valores 0..24, 0 representa el espacio vacío
    private final int indiceBlanco; // índice del espacio vacío (0..24)

    public static final int ANCHO = 5;
    public static final int NUM_FICHAS = ANCHO * ANCHO;
    public static final int[] ESTADO_OBJETIVO;

    static {
        ESTADO_OBJETIVO = new int[NUM_FICHAS];
        for (int i = 0; i < NUM_FICHAS - 1; i++) {
            ESTADO_OBJETIVO[i] = i + 1;
        }
        ESTADO_OBJETIVO[NUM_FICHAS - 1] = 0;
    }

    public Puzzle24(int[] fichas) {
        if (fichas.length != NUM_FICHAS) {
            throw new IllegalArgumentException("El estado debe contener exactamente " + NUM_FICHAS + " fichas");
        }
        this.fichas = Arrays.copyOf(fichas, fichas.length);
        this.indiceBlanco = buscarIndice(0);
    }

    private int buscarIndice(int valor) {
        for (int i = 0; i < fichas.length; i++) {
            if (fichas[i] == valor) {
                return i;
            }
        }
        throw new IllegalArgumentException("Valor " + valor + " no encontrado en el estado");
    }

    public boolean esObjetivo() {
        return Arrays.equals(fichas, ESTADO_OBJETIVO);
    }

    public Puzzle24 copiar() {
        return new Puzzle24(fichas);
    }

    /**
     * Clase auxiliar para devolver un par dirección-estado vecino.
     */
    public static class Movimiento {
        public final String direccion;
        public final Puzzle24 estado;

        public Movimiento(String d, Puzzle24 e) {
            this.direccion = d;
            this.estado = e;
        }
    }

    /**
     * Genera los estados vecinos deslizando una ficha en el espacio vacío.
     */
    public List<Movimiento> vecinos() {
        int fila = indiceBlanco / ANCHO;
        int col = indiceBlanco % ANCHO;
        List<Movimiento> resultados = new ArrayList<>();

        // desplazamientos: arriba, abajo, izquierda, derecha
        int[][] offsets = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        String[] direcciones = {"U", "D", "L", "R"};

        for (int i = 0; i < offsets.length; i++) {
            int dr = offsets[i][0];
            int dc = offsets[i][1];
            int nuevaFila = fila + dr;
            int nuevaCol = col + dc;
            if (0 <= nuevaFila && nuevaFila < ANCHO && 0 <= nuevaCol && nuevaCol < ANCHO) {
                int nuevoIndice = nuevaFila * ANCHO + nuevaCol;
                int[] nuevasFichas = Arrays.copyOf(fichas, fichas.length);
                nuevasFichas[indiceBlanco] = nuevasFichas[nuevoIndice];
                nuevasFichas[nuevoIndice] = 0;
                Puzzle24 vecino = new Puzzle24(nuevasFichas);
                resultados.add(new Movimiento(direcciones[i], vecino));
            }
        }
        return resultados;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < ANCHO; r++) {
            for (int c = 0; c < ANCHO; c++) {
                int val = fichas[r * ANCHO + c];
                if (val == 0) {
                    sb.append("   ");
                } else {
                    sb.append(String.format("%2d ", val));
                }
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /**
     * Devuelve una copia del arreglo de fichas (0..24). Útil para pruebas o
     * chequeos de solubilidad externos.
     */
    public int[] obtenerFichas() {
        return Arrays.copyOf(fichas, fichas.length);
    }

    // ----------------------------------------
    // heurísticas estáticas
    // ----------------------------------------

    /**
     * Suma de las distancias Manhattan de cada ficha a su posición objetivo.
     */
    public static int distanciaManhattan(Puzzle24 estado) {
        int sum = 0;
        for (int i = 0; i < NUM_FICHAS; i++) {
            int val = estado.fichas[i];
            if (val == 0) continue;
            int objetivo = val - 1;
            int r1 = i / ANCHO;
            int c1 = i % ANCHO;
            int r2 = objetivo / ANCHO;
            int c2 = objetivo % ANCHO;
            sum += Math.abs(r1 - r2) + Math.abs(c1 - c2);
        }
        return sum;
    }

    /**
     * Distancia Manhattan más penalizaciones por conflicto lineal.
     */
    public static int conflictoLineal(Puzzle24 estado) {
        int base = distanciaManhattan(estado);
        int penalizacion = 0;

        // filas
        for (int r = 0; r < ANCHO; r++) {
            int[] fila = new int[ANCHO];
            for (int c = 0; c < ANCHO; c++) {
                fila[c] = estado.fichas[r * ANCHO + c];
            }
            for (int i = 0; i < ANCHO; i++) {
                for (int j = i + 1; j < ANCHO; j++) {
                    int a = fila[i];
                    int b = fila[j];
                    if (a != 0 && b != 0) {
                        int ga = (a - 1) / ANCHO;
                        int gb = (b - 1) / ANCHO;
                        if (ga == r && gb == r && a > b) {
                            penalizacion += 2;
                        }
                    }
                }
            }
        }

        // columnas
        for (int c = 0; c < ANCHO; c++) {
            int[] columna = new int[ANCHO];
            for (int r = 0; r < ANCHO; r++) {
                columna[r] = estado.fichas[r * ANCHO + c];
            }
            for (int i = 0; i < ANCHO; i++) {
                for (int j = i + 1; j < ANCHO; j++) {
                    int a = columna[i];
                    int b = columna[j];
                    if (a != 0 && b != 0) {
                        int ga = (a - 1) % ANCHO;
                        int gb = (b - 1) % ANCHO;
                        if (ga == c && gb == c && a > b) {
                            penalizacion += 2;
                        }
                    }
                }
            }
        }

        return base + penalizacion;
    }

    /**
     * Comprueba si una permutación de fichas tiene solución.
     */
    public static boolean esResoluble(int[] fichas) {
        int inv = 0;
        for (int i = 0; i < fichas.length; i++) {
            if (fichas[i] == 0) continue;
            for (int j = i + 1; j < fichas.length; j++) {
                if (fichas[j] != 0 && fichas[i] > fichas[j]) {
                    inv++;
                }
            }
        }
        // ancho impar -> inversions even
        return inv % 2 == 0;
    }

    /**
     * Genera un estado aleatorio resoluble arrastrando desde el objetivo.
     */
    public static Puzzle24 estadoAleatorio(int profundidad) {
        Puzzle24 estado = new Puzzle24(ESTADO_OBJETIVO);
        Random rnd = new Random();
        String ultima = null;
        for (int i = 0; i < profundidad; i++) {
            List<Movimiento> vecinos = estado.vecinos();
            if (ultima != null) {
                String op = opuesto(ultima);
                vecinos.removeIf(m -> m.direccion.equals(op));
            }
            Puzzle24.Movimiento m = vecinos.get(rnd.nextInt(vecinos.size()));
            ultima = m.direccion;
            estado = m.estado;
        }
        return estado;
    }

    private static String opuesto(String mov) {
        switch (mov) {
            case "U": return "D";
            case "D": return "U";
            case "L": return "R";
            case "R": return "L";
            default: return null;
        }
    }
}
